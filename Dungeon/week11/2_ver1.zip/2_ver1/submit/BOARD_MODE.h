﻿#pragma once

enum class BOARD_MODE
{
	EASY_MODE,
	MEDIUM_MODE,
	HARD_MODE
};
