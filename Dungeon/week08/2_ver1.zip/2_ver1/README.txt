********************
輸入length, width 建立Canvas
若是輸入的長度Invalid，則印出警告訊息並要求使用者重新輸入。

將會在地圖上隨機生成hero*1, creture*1, trigger*2 ，物件位置不會重複
使用wasd即可以操作hero，碰到creature會扣血，碰上trigger將會增加經驗值。
********************

*已重載Position的運算符號