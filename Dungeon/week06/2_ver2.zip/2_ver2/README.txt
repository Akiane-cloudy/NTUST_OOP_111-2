***********
使用說明
***********

-Command

.1 Move (a,b):
	若(a,b)在原位置一格內，則將hero移動到(a,b)
	否則顯示 "Invalid location"
	若(a,b)不在整體範圍內也會印出 "Invalid location"

.2 Jump (a,b):
	若(a,b)在整體範圍內，則將hero移動到指定地點(a,b)
	否則顯示 "Invalid location"

.3 Exit:
	離開遊戲

.4 others:
	如非上面兩格式者看該行最後一位字元 決定WASD移動hero