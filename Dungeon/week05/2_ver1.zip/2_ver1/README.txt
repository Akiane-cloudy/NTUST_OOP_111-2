使用說明
=================
Hero:
使用w a s d 操控Hero進行上下左右的移動
起始等級為1，需要15點的經驗值才可升一級
起始血量為100

Trigger:
若Hero碰觸到Trigger，則Hero的經驗值將會增加10點

Creature:
若Hero碰觸到Creature則Hero的血量將會扣10點
若Hero出現在Creature 長度為二的直線、水平線、斜線上，則會輸出Creature看見Hero的訊息
